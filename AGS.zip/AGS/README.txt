File Descriptions

1. -- Core Simulation Engines --

AGSCMB_Solved.py: The primary integration engine. It solves the equations of motion for the scalar field
$\phi$ using a 4th-order Runge-Kutta scheme and captures the exact moment of "Horizon Exit" (N=60).

AGSCMB.py: A streamlined version of the solver focused on calculating the specific CMB observables ($n_s$ and $r$) for a given configuration.

AGSFULLDATA.py: A high-resolution export tool that simulates the entire lifecycle of the field, from the high-energy plateau
to the bottom of the potential well (reheating phase). It outputs raw data to CSV for external analysis.

2. -- Analytical & Calibration Tools --

AGSInverter.py: An inverse-problem solver. It uses numerical optimization (scipy.optimize) to determine the
exact physical constants required to match the Planck 2018 center-values.

AGS Calculator.py: A fast, algebraic utility for calculating slow-roll parameters ($\epsilon$, $\eta$) and
predicting observables without running a full differential equation integration.

3. -- Visualization --

AGSCMB_Graph.py: Generates the trajectory plots and power spectrum visualizations. It maps the field's descent and records
the evolution of the Hubble parameter.

 -- Getting Started: --

PrerequisitesThe framework requires Python 3.8+ and the standard scientific stack:

Bash
pip install numpy scipy matplotlib

 -- Running a Simulation --
To verify the AGS model's alignment with Planck data, Run the inverter to see the derived constants:

Bash
python AGSInverter.py

Run the solved trajectory to confirm 60 e-folds of expansion:

Bash
python AGSCMB_Solved.py

Inspect Source Code as needed, change constant values as needed, AGSCMB_Solved returns correct observable ouputs we see in modern physics today.


Theoretical Reference:

The theoretical foundation for this code is detailed in the accompanying paper:
"Inflationary Dynamics of the Analog Ground State (AGS) Field" DOI: 10.5281/zenodo.18032135



License:

This project is licensed under the Creative Commons Attribution 4.0 International (CC-BY 4.0) License.



Author
: Caden Lewis, University of Arkansas Community College at Batesville, Independent Researcher.


